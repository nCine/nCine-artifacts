#ifndef CLASS_NCINE_MATERIAL
#define CLASS_NCINE_MATERIAL

#include "GLShaderUniforms.h"
#include "GLShaderUniformBlocks.h"
#include "GLTexture.h"

namespace ncine {

class GLShaderProgram;
class Texture;
class GLUniformCache;
class GLAttribute;

/// The class containing material data for a drawable node
class Material
{
  public:
	/// One of the predefined shader programs
	enum class ShaderProgramType
	{
		/// Shader program for Sprite classes
		SPRITE = 0,
		/// Shader program for Sprite classes with grayscale font texture
		SPRITE_GRAY,
		/// Shader program for Sprite classes with a solid color and no texture
		SPRITE_NO_TEXTURE,
		/// Shader program for Sprite classes using attributes for instances
		SPRITE_ATTRIBS,
		/// Shader program for Sprite classes using attributes for instances, with a solid color, no texture
		SPRITE_NO_TEXTURE_ATTRIBS,
		/// Shader program for MeshSprite classes
		MESH_SPRITE,
		/// Shader program for MeshSprite classes with grayscale font texture
		MESH_SPRITE_GRAY,
		/// Shader program for MeshSprite classes with a solid color and no texture
		MESH_SPRITE_NO_TEXTURE,
		/// Shader program for TextNode classes with glyph data in alpha channel
		TEXTNODE_ALPHA,
		/// Shader program for TextNode classes with glyph data in red channel
		TEXTNODE_RED,
		/// Shader program for TextNode classes with glyph data in all channels (glyphs are colored)
		TEXTNODE_SPRITE,
		/// Shader program for a batch of Sprite classes
		BATCHED_SPRITES,
		/// Shader program for a batch of Sprite classes with grayscale font texture
		BATCHED_SPRITES_GRAY,
		/// Shader program for a batch of Sprite classes with solid colors and no texture
		BATCHED_SPRITES_NO_TEXTURE,
		/// Shader program for a batch of MeshSprite classes
		BATCHED_MESH_SPRITES,
		/// Shader program for a batch of MeshSprite classes with grayscale font texture
		BATCHED_MESH_SPRITES_GRAY,
		/// Shader program for a batch of MeshSprite classes with solid colors and no texture
		BATCHED_MESH_SPRITES_NO_TEXTURE,
		/// Shader program for a batch of TextNode classes with glyph data in alpha channel
		BATCHED_TEXTNODES_ALPHA,
		/// Shader program for a batch of TextNode classes with glyph data in red channel
		BATCHED_TEXTNODES_RED,
		/// Shader program for a batch of TextNode classes with glyph data in all channels (glyphs are colored)
		BATCHED_TEXTNODES_SPRITE,
		/// A custom shader program
		CUSTOM
	};

	// Shader uniform block and model matrix uniform names
	static const char *InstanceBlockName;
	static const char *InstancesBlockName; // for batched shaders
	static const char *ModelMatrixUniformName; // for legacy shaders using a `mat4`
	static const char *ModelTransformUniformName;
	static const char *ModelTranslationUniformName;

	// Camera related shader uniform names
	static const char *ProjectionMatrixUniformName;
	static const char *ViewMatrixUniformName;
	static const char *ProjectionViewMatrixExcludeString;

	// Shader uniform and attribute names
	static const char *TextureUniformName;
	static const char *ColorUniformName;
	static const char *SpriteSizeUniformName;
	static const char *TexRectUniformName; // for legacy shaders using a `vec4`
	static const char *UvEndpointsUUniformName;
	static const char *UvEndpointsVUniformName;
	static const char *PositionAttributeName;
	static const char *TexCoordsAttributeName;
	static const char *MeshIndexAttributeName;

	/// Default constructor
	Material();
	Material(GLShaderProgram *program, GLTexture *texture);

	inline bool isBlendingEnabled() const { return isBlendingEnabled_; }
	inline void setBlendingEnabled(bool blendingEnabled) { isBlendingEnabled_ = blendingEnabled; }

	inline GLenum srcBlendingFactor() const { return srcBlendingFactor_; }
	inline GLenum destBlendingFactor() const { return destBlendingFactor_; }
	void setBlendingFactors(GLenum srcBlendingFactor, GLenum destBlendingFactor);

	inline ShaderProgramType shaderProgramType() const { return shaderProgramType_; }
	bool setShaderProgramType(ShaderProgramType shaderProgramType);
	inline const GLShaderProgram *shaderProgram() const { return shaderProgram_; }
	inline GLShaderProgram *shaderProgram() { return shaderProgram_; }
	void setShaderProgram(GLShaderProgram *program);

	void setDefaultAttributesParameters();
	void reserveUniformsDataMemory();
	void setUniformsDataPointer(GLubyte *dataPointer);

	/// Wrapper around `GLShaderUniforms::hasUniform()`
	inline bool hasUniform(const char *name) const { return shaderUniforms_.hasUniform(name); }
	/// Wrapper around `GLShaderUniformBlocks::hasUniformBlock()`
	inline bool hasUniformBlock(const char *name) const { return shaderUniformBlocks_.hasUniformBlock(name); }

	/// Wrapper around `GLShaderUniforms::uniform()` (constant overload)
	inline const GLUniformCache *uniform(const char *name) const { return shaderUniforms_.uniform(name); }
	/// Wrapper around `GLShaderUniforms::uniform()`
	inline GLUniformCache *uniform(const char *name) { return shaderUniforms_.uniform(name); }

	/// Wrapper around `GLShaderUniformBlocks::uniformBlock()` (constant version)
	inline const GLUniformBlockCache *uniformBlock(const char *name) const { return shaderUniformBlocks_.uniformBlock(name); }
	/// Wrapper around `GLShaderUniformBlocks::uniformBlock()`
	inline GLUniformBlockCache *uniformBlock(const char *name) { return shaderUniformBlocks_.uniformBlock(name); }

	/// Wrapper around `GLShaderUniforms::allUniforms()`
	inline const GLShaderUniforms::UniformHashMapType allUniforms() const { return shaderUniforms_.allUniforms(); }
	/// Wrapper around `GLShaderUniformBlocks::allUniformBlocks()`
	inline const GLShaderUniformBlocks::UniformHashMapType allUniformBlocks() const { return shaderUniformBlocks_.allUniformBlocks(); }

	const GLTexture *texture(unsigned int unit) const;
	bool setTexture(unsigned int unit, const GLTexture *texture);
	bool setTexture(unsigned int unit, const Texture &texture);

	inline const GLTexture *texture() const { return texture(0); }
	inline bool setTexture(const GLTexture *texture) { return setTexture(0, texture); }
	inline bool setTexture(const Texture &texture) { return setTexture(0, texture); }

  private:
	bool isBlendingEnabled_;
	GLenum srcBlendingFactor_;
	GLenum destBlendingFactor_;

	ShaderProgramType shaderProgramType_;
	GLShaderProgram *shaderProgram_;
	GLShaderUniforms shaderUniforms_;
	GLShaderUniformBlocks shaderUniformBlocks_;
	const GLTexture *textures_[GLTexture::MaxTextureUnits];

	/// The size of the memory buffer containing uniform values
	unsigned int uniformsHostBufferSize_;
	/// Memory buffer with uniform values to be sent to the GPU
	nctl::UniquePtr<GLubyte[]> uniformsHostBuffer_;

	void bind();
	/// Wrapper around `GLShaderUniforms::commitUniforms()`
	inline void commitUniforms() { shaderUniforms_.commitUniforms(); }
	/// Wrapper around `GLShaderUniformBlocks::commitUniformBlocks()`
	inline void commitUniformBlocks() { shaderUniformBlocks_.commitUniformBlocks(); }
	/// Wrapper around `GLShaderProgram::defineVertexFormat()`
	void defineVertexFormat(const GLBufferObject *vbo, const GLBufferObject *ibo, unsigned int vboOffset);
	uint32_t sortKey();

	friend class RenderCommand;
};

}

#endif
