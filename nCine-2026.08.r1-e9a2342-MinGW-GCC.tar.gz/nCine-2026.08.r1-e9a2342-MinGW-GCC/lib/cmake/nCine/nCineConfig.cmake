# - Config file for the nCine package
# It defines the following variables
#   NCINE_VERSION, the nCine version string
#   NCINE_DYNAMIC_LIBRARY, set to true if the nCine library is compiled as dynamic
#   NCINE_TESTS_DATA_DIR, the directory containing the data for the tests
#   NCINE_ANDROID_DIR, the directory containing the Android library and additional files
#   NCINE_EMBEDDED_SHADERS, set to true if shaders are embedded in the library
#   NCINE_SHADERS_DIR, the directory containing the shaders if they are not embdedded

set(NCINE_VERSION "2026.08.r1-e9a2342")

####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was nCineConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

####################################################################################

if(NOT TARGET ncine AND NOT TARGET ncine::ncine)
	include("${CMAKE_CURRENT_LIST_DIR}/nCineTargets.cmake")
endif()

set(NCINE_DYNAMIC_LIBRARY ON)

find_path(NCINE_TESTS_DATA_DIR
	NAMES scripts/script.lua sounds/music.ogg textures/texture1.png
	PATHS "${PACKAGE_PREFIX_DIR}/share/ncine/data/" "${CMAKE_CURRENT_LIST_DIR}/../nCine-data/"
	DOC "Path to the data directory for tests")

find_path(NCINE_ANDROID_DIR
	NAMES app/src/main/cpp/ncine/include/ncine/AndroidApplication.h
	PATHS "${PACKAGE_PREFIX_DIR}/share/ncine/android/" "${CMAKE_CURRENT_LIST_DIR}/android"
	DOC "Path to the Android directory")

set(NCINE_EMBEDDED_SHADERS ON)
if(NOT NCINE_EMBEDDED_SHADERS)
	find_path(NCINE_SHADERS_DIR
		NAMES sprite_vs.glsl textnode_vs.glsl
		PATHS "${PACKAGE_PREFIX_DIR}/share/ncine/shaders/" "${NCINE_TESTS_DATA_DIR}/shaders" "${CMAKE_CURRENT_LIST_DIR}/../nCine/src/shaders"
		DOC "Path to the shaders directory")
endif()
