#ifndef CLASS_NCTL_ARRAY
#define CLASS_NCTL_ARRAY

#include <new>
#include <initializer_list>
#include <ncine/common_macros.h>
#include "ArrayIterator.h"
#include "ReverseIterator.h"
#include "utility.h"

#include <ncine/config.h>
#if NCINE_WITH_ALLOCATORS
	#include "AllocManager.h"
	#include "IAllocator.h"
#endif

namespace nctl {

/// Construction modes for the `Array` class
/*! Declared outside the template class to use it without template parameters. */
enum class ArrayMode
{
	/// `Array` will have a growing capacity
	GROWING_CAPACITY,
	/// `Array` will have a fixed capacity
	FIXED_CAPACITY
};

/// A dynamic array based on templates that stores elements in the heap
template <class T>
class Array
{
  public:
	/// Iterator type
	using Iterator = ArrayIterator<T, false>;
	/// Constant iterator type
	using ConstIterator = ArrayIterator<T, true>;
	/// Reverse iterator type
	using ReverseIterator = nctl::ReverseIterator<Iterator>;
	/// Reverse constant iterator type
	using ConstReverseIterator = nctl::ReverseIterator<ConstIterator>;

	/// Constructs an array without allocating memory
	Array()
	    : Array(0, ArrayMode::GROWING_CAPACITY) {}
	/// Constructs an array with explicit capacity
	explicit Array(unsigned int capacity)
	    : Array(capacity, ArrayMode::GROWING_CAPACITY) {}
	/// Constructs an array with an initializer list and explicit capacity
	Array(std::initializer_list<T> initList, unsigned int capacity)
	    : Array(initList, capacity, ArrayMode::GROWING_CAPACITY) {}
	/// Constructs an array with an initializer list, an explicit capacity, and the option for it to be fixed
	Array(std::initializer_list<T> initList, unsigned int capacity, ArrayMode mode);
#if !NCINE_WITH_ALLOCATORS
	/// Constructs an array with explicit capacity and the option for it to be fixed
	Array(unsigned int capacity, ArrayMode mode);
#else
	/// Constructs an array with explicit capacity and the option for it to be fixed
	Array(unsigned int capacity, ArrayMode mode)
	    : Array(capacity, mode, theDefaultAllocator()) {}
	/// Constructs an array with explicit capacity and a custom allocator
	Array(unsigned int capacity, IAllocator &alloc)
	    : Array(capacity, ArrayMode::GROWING_CAPACITY, alloc) {}
	/// Constructs an array with explicit capacity, the option for it to be fixed, and a custom allocator
	Array(unsigned int capacity, ArrayMode mode, IAllocator &alloc);
	/// Constructs an array with an initializer list, an explicit capacity, and a custom allocator
	Array(std::initializer_list<T> initList, unsigned int capacity, IAllocator &alloc)
	    : Array(initList, capacity, ArrayMode::GROWING_CAPACITY, alloc) {}
	/// Constructs an array with an initializer list, an explicit capacity, the option for it to be fixed, and a custom allocator
	Array(std::initializer_list<T> initList, unsigned int capacity, ArrayMode mode, IAllocator &alloc);
#endif
	~Array();

	/// Copy constructor
	Array(const Array &other);
	/// Move constructor
	Array(Array &&other);
	/// Assignment operator
	Array &operator=(const Array &other);
	/// Move assignment operator
	Array &operator=(Array &&other);

	/// Swaps two arrays without copying their data
	inline void swap(Array &first, Array &second)
	{
#if NCINE_WITH_ALLOCATORS
		nctl::swap(first.alloc_, second.alloc_);
#endif
		nctl::swap(first.array_, second.array_);
		nctl::swap(first.size_, second.size_);
		nctl::swap(first.capacity_, second.capacity_);
		nctl::swap(first.fixedCapacity_, second.fixedCapacity_);
	}

	/// Returns an iterator to the beginning
	inline Iterator begin() { return Iterator(array_); }
	/// Returns a reverse iterator to the beginning
	inline ReverseIterator rBegin() { return ReverseIterator(end()); }
	/// Returns an iterator to the end
	inline Iterator end() { return Iterator(array_ + size_); }
	/// Returns a reverse iterator to the end
	inline ReverseIterator rEnd() { return ReverseIterator(begin()); }

	/// Returns a constant iterator to the beginning
	inline ConstIterator begin() const { return ConstIterator(array_); }
	/// Returns a constant reverse iterator to beginning
	inline ConstReverseIterator rBegin() const { return ConstReverseIterator(cEnd()); }
	/// Returns a constant iterator to the end
	inline ConstIterator end() const { return ConstIterator(array_ + size_); }
	/// Returns a constant reverse iterator to the end
	inline ConstReverseIterator rEnd() const { return ConstReverseIterator(cBegin()); }

	/// Returns a constant iterator to the beginning
	inline ConstIterator cBegin() const { return ConstIterator(array_); }
	/// Returns a constant reverse iterator to the beginning
	inline ConstReverseIterator crBegin() const { return ConstReverseIterator(cEnd()); }
	/// Returns a constant iterator to past the end
	inline ConstIterator cEnd() const { return ConstIterator(array_ + size_); }
	/// Returns a constant reverse iterator to the end
	inline ConstReverseIterator crEnd() const { return ConstReverseIterator(cBegin()); }

	/// Returns true if the array is empty
	inline bool isEmpty() const { return size_ == 0; }
	/// Returns the array size
	/*! The array is filled without gaps until the `Size()`-1 element. */
	inline unsigned int size() const { return size_; }
	/// Returns the array capacity
	/*! The array has memory allocated to store until the `Capacity()`-1 element. */
	inline unsigned int capacity() const { return capacity_; }
	/// Sets a new size for the array (allowing for "holes")
	void setSize(unsigned int newSize);
	/// Sets a new capacity for the array (can be bigger or smaller than the current one)
	void setCapacity(unsigned int newCapacity);
	/// Decreases the capacity to match the current size of the array
	void shrinkToFit();

	/// Clears the array
	void clear();
	/// Returns a constant reference to the first element in constant time
	const T &front() const;
	/// Returns a reference to the first element in constant time
	T &front();
	/// Returns a constant reference to the last element in constant time
	const T &back() const;
	/// Returns a reference to the last element in constant time
	T &back();
	/// Appends a new element in constant time, the element is copied into the array
	inline void pushBack(const T &element) { new (extendOne()) T(element); }
	/// Appends a new element in constant time, the element is moved into the array
	inline void pushBack(T &&element) { new (extendOne()) T(nctl::move(element)); }
	/// Constructs a new element at the end of the array
	template <typename... Args> void emplaceBack(Args &&... args);
	/// Removes the last element in constant time
	void popBack();
	/// Inserts new elements at the specified position from a source range, last not included (shifting elements around)
	T *insertRange(unsigned int index, const T *firstPtr, const T *lastPtr);
	/// Inserts new elements at a specified position with an initializer list (shifting elements around)
	T *insertRange(unsigned int index, std::initializer_list<T> initList);
	/// Inserts a new element at a specified position (shifting elements around)
	T *insertAt(unsigned int index, const T &element);
	/// Move inserts a new element at a specified position (shifting elements around)
	T *insertAt(unsigned int index, T &&element);
	/// Constructs a new element at the position specified by the index
	template <typename... Args> T *emplaceAt(unsigned int index, Args &&... args);
	/// Inserts a new element at the position specified by the iterator (shifting elements around)
	Iterator insert(Iterator position, const T &value);
	/// Move inserts a new element at the position specified by the iterator (shifting elements around)
	Iterator insert(Iterator position, T &&value);
	/// Inserts new elements from a source at the position specified by the iterator (shifting elements around)
	Iterator insert(Iterator position, Iterator first, Iterator last);
	/// Inserts new elements with an initializer list at the position specified by the iterator (shifting elements around)
	Iterator insert(Iterator position, std::initializer_list<T> initList);
	/// Constructs a new element at the position specified by the iterator
	template <typename... Args> Iterator emplace(Iterator position, Args &&... args);

	/// Removes the specified range of elements, last not included (shifting elements around)
	T *removeRange(unsigned int firstIndex, unsigned int lastIndex);
	/// Removes an element at a specified position (shifting elements around)
	inline Iterator removeAt(unsigned int index) { return Iterator(removeRange(index, index + 1)); }
	/// Removes the element pointed by the iterator (shifting elements around)
	Iterator erase(Iterator position);
	/// Removes the elements in the range, last not included (shifting elements around)
	Iterator erase(Iterator first, Iterator last);

	/// Removes the specified range of elements, last not included (moving tail elements in place)
	T *unorderedRemoveRange(unsigned int firstIndex, unsigned int lastIndex);
	/// Removes an element at a specified position (moving the last element in place)
	inline Iterator unorderedRemoveAt(unsigned int index) { return Iterator(unorderedRemoveRange(index, index + 1)); }
	/// Removes the element pointed by the iterator (moving the last element in place)
	Iterator unorderedErase(Iterator position);
	/// Removes the elements in the range, last not included (moving tail elements in place)
	Iterator unorderedErase(Iterator first, Iterator last);

	/// Read-only access to the specified element (with bounds checking)
	const T &at(unsigned int index) const;
	/// Access to the specified element (with bounds checking)
	T &at(unsigned int index);
	/// Read-only subscript operator
	const T &operator[](unsigned int index) const;
	/// Subscript operator
	T &operator[](unsigned int index);

	/// Returns a constant pointer to the allocated memory
	inline const T *data() const { return array_; }
	/// Returns a pointer to the allocated memory
	/*! When adding new elements through a pointer the size field is not updated, like with `std::vector`. */
	inline T *data() { return array_; }

  private:
#if NCINE_WITH_ALLOCATORS
	/// The custom memory allocator for the array
	IAllocator &alloc_;
#endif
	T *array_;
	unsigned int size_;
	unsigned int capacity_;
	bool fixedCapacity_;

	/// Implementation of `setCapacity()` based on object policy tag
	template <class Tag>
	void setCapacityImpl(unsigned int newCapacity, Tag);
	/// Implementation of `setCapacity()` for non-movable types
	void setCapacityImpl(unsigned int newCapacity, detail::NonMovableTag);

	/// Grows the array size by one and returns a pointer to the new element
	T *extendOne();
};

template <class T>
Array<T>::Array(std::initializer_list<T> initList, unsigned int capacity, ArrayMode mode)
    : Array(capacity, mode)
{
	insertRange(0, initList);
}

#if !NCINE_WITH_ALLOCATORS
template <class T>
Array<T>::Array(unsigned int capacity, ArrayMode mode)
    : array_(nullptr), size_(0), capacity_(0), fixedCapacity_(mode == ArrayMode::FIXED_CAPACITY)
{
	if (capacity > 0)
		setCapacity(capacity);
}
#else
template <class T>
Array<T>::Array(unsigned int capacity, ArrayMode mode, IAllocator &alloc)
    : alloc_(alloc), array_(nullptr), size_(0), capacity_(0),
      fixedCapacity_(mode == ArrayMode::FIXED_CAPACITY)
{
	if (capacity > 0)
		setCapacity(capacity);
}

template <class T>
Array<T>::Array(std::initializer_list<T> initList, unsigned int capacity, ArrayMode mode, IAllocator &alloc)
    : Array(capacity, mode, alloc)
{
	insertRange(0, initList);
}
#endif

template <class T>
Array<T>::~Array()
{
	destructArray(array_, size_);
#if !NCINE_WITH_ALLOCATORS
	::operator delete(array_);
#else
	alloc_.deallocate(array_);
#endif
}

template <class T>
Array<T>::Array(const Array<T> &other)
    :
#if NCINE_WITH_ALLOCATORS
      alloc_(other.alloc_),
#endif
      array_(nullptr), size_(other.size_), capacity_(other.capacity_), fixedCapacity_(other.fixedCapacity_)
{
#if !NCINE_WITH_ALLOCATORS
	array_ = static_cast<T *>(::operator new(capacity_ * sizeof(T)));
#else
	array_ = static_cast<T *>(alloc_.allocate(capacity_ * sizeof(T)));
#endif
	copyConstructArray(array_, other.array_, size_);
}

template <class T>
Array<T>::Array(Array<T> &&other)
    :
#if NCINE_WITH_ALLOCATORS
      alloc_(other.alloc_),
#endif
      array_(nullptr), size_(0), capacity_(0), fixedCapacity_(false)
{
	swap(*this, other);
}

template <class T>
Array<T> &Array<T>::operator=(const Array<T> &other)
{
	if (this == &other)
		return *this;

	if (other.size_ > capacity_)
		setCapacity(other.size_);

	if (other.size_ > 0 && other.size_ >= size_)
	{
		copyAssignArray(array_, other.array_, size_);
		copyConstructArray(array_ + size_, other.array_ + size_, other.size_ - size_);
	}
	else if (size_ > 0 && size_ >= other.size_)
	{
		copyAssignArray(array_, other.array_, other.size_);
		destructArray(array_ + other.size_, size_ - other.size_);
	}

	size_ = other.size_;
	return *this;
}

template <class T>
Array<T> &Array<T>::operator=(Array<T> &&other)
{
	if (this != &other)
	{
		swap(*this, other);
		other.clear();
	}
	return *this;
}

template <class T>
void Array<T>::setSize(unsigned int newSize)
{
	const int newElements = newSize - size_;

	if (newSize > capacity_)
	{
		setCapacity(newSize);
		// Modifying size only if the capacity is not fixed
		if (capacity_ < newSize)
			return;
	}

	if (newElements > 0)
		constructArray(array_ + size_, newElements);
	else if (newElements < 0)
		destructArray(array_ + size_ + newElements, -newElements);
	size_ += newElements;
}

template <class T>
void Array<T>::setCapacity(unsigned int newCapacity)
{
	setCapacityImpl(newCapacity, typename detail::ObjectPolicyTag<T>::type{});
}

template <class T>
void Array<T>::shrinkToFit()
{
	if (size_ > 0)
		setCapacity(size_);
}

/*! \note Size will be set to zero but capacity remains unmodified. */
template <class T>
void Array<T>::clear()
{
	destructArray(array_, size_);
	size_ = 0;
}

template <class T>
const T &Array<T>::front() const
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot retrieve an element from an empty array");
	return array_[0];
}

template <class T>
T &Array<T>::front()
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot retrieve an element from an empty array");
	return array_[0];
}

template <class T>
const T &Array<T>::back() const
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot retrieve an element from an empty array");
	return array_[size_ - 1];
}

template <class T>
T &Array<T>::back()
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot retrieve an element from an empty array");
	return array_[size_ - 1];
}

template <class T>
template <typename... Args>
void Array<T>::emplaceBack(Args &&... args)
{
	new (extendOne()) T(nctl::forward<Args>(args)...);
}

template <class T>
void Array<T>::popBack()
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot pop an element from an empty array");
	destructObject(array_ + size_ - 1);
	size_--;
}

template <class T>
T *Array<T>::insertRange(unsigned int index, const T *firstPtr, const T *lastPtr)
{
	// Cannot insert at more than one position after the last element
	FATAL_ASSERT_MSG_X(index <= size_, "Index %u is out of bounds (size: %u)", index, size_);
	FATAL_ASSERT_MSG_X(firstPtr <= lastPtr, "First pointer %p should precede or be equal to the last one %p", firstPtr, lastPtr);

	const unsigned int numElements = static_cast<unsigned int>(lastPtr - firstPtr);
	if (numElements == 0)
		return (array_ + index);

	if (size_ + numElements > capacity_)
		setCapacity((size_ + numElements) * 2);

	// Backwards loop to account for overlapping areas
	for (unsigned int i = size_ - index; i > 0; i--)
	{
		T *src = &array_[index + i - 1];
		T *dst = &array_[index + numElements + i - 1];

		moveConstructObject(dst, src);
		destructObject(src);
	}
	copyConstructArray(array_ + index, firstPtr, numElements);
	size_ += numElements;

	return (array_ + index + numElements);
}

template <class T>
T *Array<T>::insertRange(unsigned int index, std::initializer_list<T> initList)
{
	typename std::initializer_list<T>::const_iterator end = initList.end();
	if (fixedCapacity_)
	{
		const unsigned int MaxInsertions = capacity_ - size_;
		if (end - initList.begin() > MaxInsertions)
			end = initList.begin() + MaxInsertions;
	}

	return insertRange(index, initList.begin(), end);
}

template <class T>
T *Array<T>::insertAt(unsigned int index, const T &element)
{
	// Cannot insert at more than one position after the last element
	FATAL_ASSERT_MSG_X(index <= size_, "Index %u is out of bounds (size: %u)", index, size_);

	if (size_ + 1 > capacity_)
	{
		const unsigned int newCapacity = (size_ == 0) ? 1 : size_ * 2;
		setCapacity(newCapacity);
	}

	if (index < size_)
	{
		// Backwards loop to move-construct into the next slot
		for (unsigned int i = size_; i > index; i--)
		{
			T *src = &array_[i - 1];
			T *dst = &array_[i];

			moveConstructObject(dst, src);
			destructObject(src);
		}
	}
	copyConstructObject(array_ + index, &element);
	size_++;

	return (array_ + index + 1);
}

template <class T>
T *Array<T>::insertAt(unsigned int index, T &&element)
{
	// Cannot insert at more than one position after the last element
	FATAL_ASSERT_MSG_X(index <= size_, "Index %u is out of bounds (size: %u)", index, size_);

	if (size_ + 1 > capacity_)
	{
		const unsigned int newCapacity = (size_ == 0) ? 1 : size_ * 2;
		setCapacity(newCapacity);
	}

	if (index < size_)
	{
		for (unsigned int i = size_; i > index; i--)
		{
			T *src = &array_[i - 1];
			T *dst = &array_[i];

			moveConstructObject(dst, src);
			destructObject(src);
		}
	}
	moveConstructObject(array_ + index, &element);
	size_++;

	return (array_ + index + 1);
}

template <class T>
template <typename... Args>
T *Array<T>::emplaceAt(unsigned int index, Args &&... args)
{
	// Cannot emplace at more than one position after the last element
	FATAL_ASSERT_MSG_X(index <= size_, "Index %u is out of bounds (size: %u)", index, size_);

	if (size_ + 1 > capacity_)
	{
		const unsigned int newCapacity = (size_ == 0) ? 1 : size_ * 2;
		setCapacity(newCapacity);
	}

	if (index < size_)
	{
		for (unsigned int i = size_; i > index; i--)
		{
			T *src = &array_[i - 1];
			T *dst = &array_[i];

			moveConstructObject(dst, src);
			destructObject(src);
		}
	}
	new (array_ + index) T(nctl::forward<Args>(args)...);
	size_++;

	return (array_ + index + 1);
}

template <class T>
typename Array<T>::Iterator Array<T>::insert(Iterator position, const T &value)
{
	const unsigned int index = &(*position) - array_;
	T *nextElement = insertAt(index, value);

	return Iterator(nextElement);
}

template <class T>
typename Array<T>::Iterator Array<T>::insert(Iterator position, T &&value)
{
	const unsigned int index = &(*position) - array_;
	T *nextElement = insertAt(index, nctl::move(value));

	return Iterator(nextElement);
}

template <class T>
typename Array<T>::Iterator Array<T>::insert(Iterator position, Iterator first, Iterator last)
{
	const unsigned int index = static_cast<unsigned int>(&(*position) - array_);
	const T *firstPtr = &(*first);
	const T *lastPtr = &(*last);
	T *nextElement = insertRange(index, firstPtr, lastPtr);

	return Iterator(nextElement);
}

template <class T>
typename Array<T>::Iterator Array<T>::insert(Iterator position, std::initializer_list<T> initList)
{
	const unsigned int index = static_cast<unsigned int>(&(*position) - array_);
	T *nextElement = insertRange(index, initList);

	return Iterator(nextElement);
}

template <class T>
template <typename... Args>
typename Array<T>::Iterator Array<T>::emplace(Iterator position, Args &&... args)
{
	const unsigned int index = &(*position) - array_;
	T *nextElement = emplaceAt(index, nctl::forward<Args>(args)...);

	return Iterator(nextElement);
}

template <class T>
T *Array<T>::removeRange(unsigned int firstIndex, unsigned int lastIndex)
{
	// Cannot remove past the last element
	FATAL_ASSERT_MSG_X(firstIndex < size_, "First index %u out of size range", firstIndex);
	FATAL_ASSERT_MSG_X(lastIndex <= size_, "Last index %u out of size range", lastIndex);
	FATAL_ASSERT_MSG_X(firstIndex <= lastIndex, "First index %u should precede or be equal to the last one %u", firstIndex, lastIndex);

	const unsigned int numElements = lastIndex - firstIndex;
	moveAssignArray(array_ + firstIndex, array_ + lastIndex, size_ - lastIndex);
	destructArray(array_ + size_ - numElements, numElements);
	size_ -= numElements;

	return (array_ + firstIndex);
}

template <class T>
typename Array<T>::Iterator Array<T>::erase(Iterator position)
{
	const unsigned int index = static_cast<unsigned int>(&(*position) - array_);
	return removeAt(index);
}

template <class T>
typename Array<T>::Iterator Array<T>::erase(Iterator first, Iterator last)
{
	const unsigned int firstIndex = static_cast<unsigned int>(&(*first) - array_);
	const unsigned int lastIndex = static_cast<unsigned int>(&(*last) - array_);
	T *nextElement = removeRange(firstIndex, lastIndex);

	return Iterator(nextElement);
}

/*! \note This method is faster than `removeRange()` but it will not preserve the array order */
template <class T>
T *Array<T>::unorderedRemoveRange(unsigned int firstIndex, unsigned int lastIndex)
{
	// Cannot remove past the last element
	FATAL_ASSERT_MSG_X(firstIndex < size_, "First index %u out of size range", firstIndex);
	FATAL_ASSERT_MSG_X(lastIndex <= size_, "Last index %u out of size range", lastIndex);
	FATAL_ASSERT_MSG_X(firstIndex <= lastIndex, "First index %u should precede or be equal to the last one %u", firstIndex, lastIndex);

	const unsigned int numElements = lastIndex - firstIndex;
	for (unsigned int i = 0; i < numElements; i++)
		array_[firstIndex + i] = nctl::move(array_[size_ - i - 1]);
	destructArray(array_ + size_ - numElements, numElements);
	size_ -= numElements;

	return (array_ + firstIndex + 1);
}

/*! \note This method is faster than `erase()` but it will not preserve the array order */
template <class T>
typename Array<T>::Iterator Array<T>::unorderedErase(Iterator position)
{
	const unsigned int index = static_cast<unsigned int>(&(*position) - array_);
	return unorderedRemoveAt(index);
}

/*! \note This method is faster than `erase()` but it will not preserve the array order */
template <class T>
typename Array<T>::Iterator Array<T>::unorderedErase(Iterator first, Iterator last)
{
	const unsigned int firstIndex = static_cast<unsigned int>(&(*first) - array_);
	const unsigned int lastIndex = static_cast<unsigned int>(&(*last) - array_);
	T *nextElement = unorderedRemoveRange(firstIndex, lastIndex);

	return Iterator(nextElement);
}

template <class T>
const T &Array<T>::at(unsigned int index) const
{
	FATAL_ASSERT_MSG_X(index < size_, "Index %u is out of bounds (size: %u)", index, size_);
	return operator[](index);
}

template <class T>
T &Array<T>::at(unsigned int index)
{
	FATAL_ASSERT_MSG_X(index < size_, "Index %u is out of bounds (size: %u)", index, size_);
	return operator[](index);
}

template <class T>
const T &Array<T>::operator[](unsigned int index) const
{
	ASSERT_MSG_X(index < size_, "Index %u is out of bounds (size: %u)", index, size_);
	return array_[index];
}

template <class T>
T &Array<T>::operator[](unsigned int index)
{
	ASSERT_MSG_X(index < size_, "Index %u is out of bounds (size: %u)", index, size_);
	return array_[index];
}

template <class T>
template <class Tag>
void Array<T>::setCapacityImpl(unsigned int newCapacity, Tag)
{
	// If the call does not come from the constructor
	if (capacity_ != 0)
	{
		if (newCapacity == capacity_)
		{
			LOGW_X("Array capacity already equal to %u", capacity_);
			return;
		}
		else
		{
			// Setting a new capacity is disabled if the array is fixed
			FATAL_ASSERT_MSG_X(fixedCapacity_ == false, "Trying to change the capacity of a fixed array, from %u to %u", capacity_, newCapacity);

			if (newCapacity == capacity_)
			{
				LOGW_X("Array capacity already equal to %u", capacity_);
				return;
			}
			else if (newCapacity < capacity_)
				LOGI_X("Array capacity shrinking from %u to %u", capacity_, newCapacity);
			else // (newCapacity > capacity_)
				LOGD_X("Array capacity growing from %u to %u", capacity_, newCapacity);
		}
	}

	T *newArray = nullptr;
	if (newCapacity > 0)
	{
#if !NCINE_WITH_ALLOCATORS
		newArray = static_cast<T *>(::operator new(newCapacity * sizeof(T)));
#else
		newArray = static_cast<T *>(alloc_.allocate(newCapacity * sizeof(T)));
#endif
	}

	if (size_ > 0)
	{
		const unsigned int oldSize = size_;
		if (newCapacity < size_) // shrinking
			size_ = newCapacity; // cropping last elements

		moveConstructArray(newArray, array_, size_);
		destructArray(array_, oldSize);
	}

#if !NCINE_WITH_ALLOCATORS
	::operator delete(array_);
#else
	alloc_.deallocate(array_);
#endif
	array_ = newArray;
	capacity_ = newCapacity;
}

/*! \note This version can be used to set an initial capacity of arrays with non-movable and non-copyable types */
template <class T>
void Array<T>::setCapacityImpl(unsigned int newCapacity, detail::NonMovableTag)
{
	// If the call does not come from the constructor
	if (capacity_ != 0)
	{
		if (newCapacity == capacity_)
		{
			LOGW_X("Array capacity already equal to %u", capacity_);
			return;
		}
		else
		{
			// Setting a new capacity is disabled if the array is fixed
			FATAL_ASSERT_MSG_X(fixedCapacity_ == false, "Trying to change the capacity of a fixed array, from %u to %u", capacity_, newCapacity);

			if (size_ == 0)
			{
				if (newCapacity < capacity_)
					LOGI_X("Array capacity shrinking from %u to %u", capacity_, newCapacity);
				else // (newCapacity > capacity_)
					LOGD_X("Array capacity growing from %u to %u", capacity_, newCapacity);
			}
			else
				FATAL_ASSERT_MSG_X(size_ == 0, "Trying to change the capacity of a non-empty array of non-movable and non-copyable objects, from %u to %u", capacity_, newCapacity);
		}
	}

	T *newArray = nullptr;
	if (newCapacity > 0)
	{
#if !NCINE_WITH_ALLOCATORS
		newArray = static_cast<T *>(::operator new(newCapacity * sizeof(T)));
#else
		newArray = static_cast<T *>(alloc_.allocate(newCapacity * sizeof(T)));
#endif
	}

#if !NCINE_WITH_ALLOCATORS
	::operator delete(array_);
#else
	alloc_.deallocate(array_);
#endif
	array_ = newArray;
	capacity_ = newCapacity;
}

template <class T>
T *Array<T>::extendOne()
{
	// Need growing
	if (size_ == capacity_)
	{
		const unsigned int newCapacity = (capacity_ == 0) ? 1 : capacity_ * 2;
		setCapacity(newCapacity);
		// Extending size only if the capacity is not fixed
		FATAL_ASSERT_MSG_X(capacity_ == newCapacity, "Cannot extend array capacity to %u elements", newCapacity);
		if (capacity_ == newCapacity)
			size_++;
	}
	else
		size_++;

	return array_ + size_ - 1;
}

}

#endif
