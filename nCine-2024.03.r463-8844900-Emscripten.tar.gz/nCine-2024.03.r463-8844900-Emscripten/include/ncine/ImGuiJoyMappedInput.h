#ifndef CLASS_NCINE_IMGUIJOYMAPPEDINPUT
#define CLASS_NCINE_IMGUIJOYMAPPEDINPUT

namespace ncine {

bool imGuiJoyMappedInput();

}

#endif
