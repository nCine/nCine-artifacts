#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ncine::ncine" for configuration "Release"
set_property(TARGET ncine::ncine APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ncine::ncine PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "GLEW::GLEW;GLFW::GLFW;OpenAL::AL;Vorbis::Vorbisfile;WebP::WebP;Lua::Lua"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libncine.so"
  IMPORTED_SONAME_RELEASE "libncine.so"
  )

list(APPEND _cmake_import_check_targets ncine::ncine )
list(APPEND _cmake_import_check_files_for_ncine::ncine "${_IMPORT_PREFIX}/lib/libncine.so" )

# Import target "ncine::ncine_main" for configuration "Release"
set_property(TARGET ncine::ncine_main APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ncine::ncine_main PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libncine_main.a"
  )

list(APPEND _cmake_import_check_targets ncine::ncine_main )
list(APPEND _cmake_import_check_files_for_ncine::ncine_main "${_IMPORT_PREFIX}/lib/libncine_main.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
