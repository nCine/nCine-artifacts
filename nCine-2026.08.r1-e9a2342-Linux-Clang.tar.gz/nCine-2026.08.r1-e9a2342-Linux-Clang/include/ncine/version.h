#ifndef NCINE_VERSION
#define NCINE_VERSION

#include <ncine/common_defines.h>

namespace ncine {

struct DLL_PUBLIC VersionStrings
{
	static const char *Version;
	static const char *GitRevCount;
	static const char *GitShortHash;
	static const char *GitLastCommitDate;
	static const char *GitBranch;
	static const char *GitTag;
	static const char *CompilationDate;
	static const char *CompilationTime;
};

struct DLL_PUBLIC VersionNumbers
{
	static const unsigned int Major;
	static const unsigned int Minor;
	static const unsigned int Patch;
	static const unsigned int Year;
	static const unsigned int Month;
	static const unsigned int Day;
	static const unsigned int GitRevCount;
};

}

#endif