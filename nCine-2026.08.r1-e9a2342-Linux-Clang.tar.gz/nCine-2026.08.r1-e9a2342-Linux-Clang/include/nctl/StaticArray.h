#ifndef CLASS_NCTL_STATICARRAY
#define CLASS_NCTL_STATICARRAY

#include <new>
#include <initializer_list>
#include <ncine/common_macros.h>
#include "ArrayIterator.h"
#include "ReverseIterator.h"
#include "utility.h"

namespace nctl {

/// Construction modes for the `StaticArray` class
/*! Declared outside the template class to use it without template parameters. */
enum class StaticArrayMode
{
	/// `StaticArray` will have a zero size
	ZERO_SIZE,
	/// `StaticArray` will extend the size to match its capacity
	EXTEND_SIZE
};

/// A static array based on templates that stores elements in the stack
template <class T, unsigned int Capacity>
class StaticArray
{
  public:
	/// Iterator type
	using Iterator = ArrayIterator<T, false>;
	/// Constant iterator type
	using ConstIterator = ArrayIterator<T, true>;
	/// Reverse iterator type
	using ReverseIterator = nctl::ReverseIterator<Iterator>;
	/// Reverse constant iterator type
	using ConstReverseIterator = nctl::ReverseIterator<ConstIterator>;

	/// Constructs an empty array with fixed capacity
	/*! \note Not using a delegating constructor to be able to use non-movable and non-copyable types. */
	StaticArray()
	    : size_(0) {}
	/// Constructs an array with the option for it to have the size match its capacity
	explicit StaticArray(StaticArrayMode mode);
	/// Constructs an array with an initializer list
	StaticArray(std::initializer_list<T> initList);
	~StaticArray() { destructArray(array_, size_); }

	/// Copy constructor
	StaticArray(const StaticArray &other);
	/// Move constructor
	StaticArray(StaticArray &&other);
	/// Assignment operator
	StaticArray &operator=(const StaticArray &other);
	/// Move assignment operator
	StaticArray &operator=(StaticArray &&other);

	/// Conversion constructor from an array of different capacity
	template <unsigned int Capacity2>
	StaticArray(const StaticArray<T, Capacity2> &other);
	/// Assignment operator from an array of different capacity
	template <unsigned int Capacity2>
	StaticArray &operator=(const StaticArray<T, Capacity2> &other);

	/// Returns an iterator to the beginning
	inline Iterator begin() { return Iterator(array_); }
	/// Returns a reverse iterator to the beginning
	inline ReverseIterator rBegin() { return ReverseIterator(end()); }
	/// Returns an iterator to the end
	inline Iterator end() { return Iterator(array_ + size_); }
	/// Returns a reverse iterator to the end
	inline ReverseIterator rEnd() { return ReverseIterator(begin()); }

	/// Returns a constant iterator to the beginning
	inline ConstIterator begin() const { return ConstIterator(array_); }
	/// Returns a constant reverse iterator to the beginning
	inline ConstReverseIterator rBegin() const { return ConstReverseIterator(cEnd()); }
	/// Returns a constant iterator to the end
	inline ConstIterator end() const { return ConstIterator(array_ + size_); }
	/// Returns a constant reverse iterator to the end
	inline ConstReverseIterator rEnd() const { return ConstReverseIterator(cBegin()); }

	/// Returns a constant iterator to the beginning
	inline ConstIterator cBegin() const { return ConstIterator(array_); }
	/// Returns a constant reverse iterator to the beginning
	inline ConstReverseIterator crBegin() const { return ConstReverseIterator(cEnd()); }
	/// Returns a constant iterator to the end
	inline ConstIterator cEnd() const { return ConstIterator(array_ + size_); }
	/// Returns a constant reverse iterator to the end
	inline ConstReverseIterator crEnd() const { return ConstReverseIterator(cBegin()); }

	/// Returns true if the array is empty
	inline bool isEmpty() const { return size_ == 0; }
	/// Returns the array size
	/*! The array is filled without gaps until the `Size()`-1 element. */
	inline unsigned int size() const { return size_; }
	/// Returns the array capacity
	inline unsigned int capacity() const { return Capacity; }
	/// Sets a new size for the array (allowing for "holes")
	void setSize(unsigned int newSize);

	/// Clears the array
	void clear();
	/// Returns a constant reference to the first element in constant time
	const T &front() const;
	/// Returns a reference to the first element in constant time
	T &front();
	/// Returns a constant reference to the last element in constant time
	const T &back() const;
	/// Returns a reference to the last element in constant time
	T &back();
	/// Inserts a new element as the last one in constant time
	inline void pushBack(const T &element) { new (extendOne()) T(element); }
	/// Move inserts a new element as the last one in constant time
	inline void pushBack(T &&element) { new (extendOne()) T(nctl::move(element)); }
	/// Constructs a new element as the last one in constant time
	template <typename... Args> void emplaceBack(Args &&... args);
	/// Removes the last element in constant time
	void popBack();
	/// Inserts new elements at the specified position from a source range, last not included (shifting elements around)
	T *insertRange(unsigned int index, const T *firstPtr, const T *lastPtr);
	/// Inserts new elements at a specified position with an initializer list (shifting elements around)
	T *insertRange(unsigned int index, std::initializer_list<T> initList);
	/// Inserts a new element at a specified position (shifting elements around)
	T *insertAt(unsigned int index, const T &element);
	/// Move inserts a new element at a specified position (shifting elements around)
	T *insertAt(unsigned int index, T &&element);
	/// Constructs a new element at the position specified by the index
	template <typename... Args> T *emplaceAt(unsigned int index, Args &&... args);
	/// Inserts a new element at the position specified by the iterator (shifting elements around)
	Iterator insert(Iterator position, const T &value);
	/// Move inserts a new element at the position specified by the iterator (shifting elements around)
	Iterator insert(Iterator position, T &&value);
	/// Inserts new elements from a source at the position specified by the iterator (shifting elements around)
	Iterator insert(Iterator position, Iterator first, Iterator last);
	/// Inserts new elements with an initializer list at the position specified by the iterator (shifting elements around)
	Iterator insert(Iterator position, std::initializer_list<T> initList);
	/// Constructs a new element at the position specified by the iterator
	template <typename... Args> Iterator emplace(Iterator position, Args &&... args);

	/// Removes the specified range of elements, last not included (shifting elements around)
	T *removeRange(unsigned int firstIndex, unsigned int lastIndex);
	/// Removes an element at a specified position (shifting elements around)
	inline Iterator removeAt(unsigned int index) { return Iterator(removeRange(index, index + 1)); }
	/// Removes the element pointed by the iterator (shifting elements around)
	Iterator erase(Iterator position);
	/// Removes the elements in the range, last not included (shifting elements around)
	Iterator erase(Iterator first, Iterator last);

	/// Removes the specified range of elements, last not included (moving tail elements in place)
	T *unorderedRemoveRange(unsigned int firstIndex, unsigned int lastIndex);
	/// Removes an element at a specified position (moving the last element in place)
	inline Iterator unorderedRemoveAt(unsigned int index) { return Iterator(unorderedRemoveRange(index, index + 1)); }
	/// Removes the element pointed by the iterator (moving the last element in place)
	Iterator unorderedErase(Iterator position);
	/// Removes the elements in the range, last not included (moving tail elements in place)
	Iterator unorderedErase(Iterator first, Iterator last);

	/// Read-only access to the specified element (with bounds checking)
	const T &at(unsigned int index) const;
	/// Access to the specified element (with bounds checking)
	T &at(unsigned int index);
	/// Read-only subscript operator
	const T &operator[](unsigned int index) const;
	/// Subscript operator
	T &operator[](unsigned int index);

	/// Returns a constant pointer to the allocated memory
	inline const T *data() const { return array_; }
	/// Returns a pointer to the allocated memory
	inline T *data() { return array_; }

  private:
	unsigned char arrayBuffer_[Capacity * sizeof(T)];
	T *array_ = reinterpret_cast<T *>(arrayBuffer_);
	unsigned int size_;

	/// Grows the array size by one and returns a pointer to the new element
	T *extendOne();
};

template <class T, unsigned int Capacity>
StaticArray<T, Capacity>::StaticArray(StaticArrayMode mode)
    : size_(0)
{
	if (mode == StaticArrayMode::EXTEND_SIZE)
		setSize(Capacity);
}

template <class T, unsigned int Capacity>
StaticArray<T, Capacity>::StaticArray(std::initializer_list<T> initList)
    : StaticArray()
{
	insertRange(0, initList);
}

template <class T, unsigned int Capacity>
StaticArray<T, Capacity>::StaticArray(const StaticArray<T, Capacity> &other)
    : size_(other.size_)
{
	copyConstructArray(array_, other.array_, size_);
}

template <class T, unsigned int Capacity>
StaticArray<T, Capacity>::StaticArray(StaticArray<T, Capacity> &&other)
    : size_(other.size_)
{
	moveConstructArray(array_, other.array_, size_);
	other.clear();
}

template <class T, unsigned int Capacity>
StaticArray<T, Capacity> &StaticArray<T, Capacity>::operator=(const StaticArray<T, Capacity> &other)
{
	if (this == &other)
		return *this;

	if (other.size_ > 0 && other.size_ >= size_)
	{
		copyAssignArray(array_, other.array_, size_);
		copyConstructArray(array_ + size_, other.array_ + size_, other.size_ - size_);
	}
	else if (size_ > 0 && size_ >= other.size_)
	{
		copyAssignArray(array_, other.array_, other.size_);
		destructArray(array_ + other.size_, size_ - other.size_);
	}

	size_ = other.size_;
	return *this;
}

template <class T, unsigned int Capacity>
StaticArray<T, Capacity> &StaticArray<T, Capacity>::operator=(StaticArray<T, Capacity> &&other)
{
	if (this == &other)
		return *this;

	if (other.size_ > 0 && other.size_ >= size_)
	{
		moveAssignArray(array_, other.array_, size_);
		moveConstructArray(array_ + size_, other.array_ + size_, other.size_ - size_);
	}
	else if (size_ > 0 && size_ >= other.size_)
	{
		moveAssignArray(array_, other.array_, other.size_);
		destructArray(array_ + other.size_, size_ - other.size_);
	}

	size_ = other.size_;
	other.clear();
	return *this;
}

/*! \note Copy could be truncated if the other array is bigger than its capacity. */
template <class T, unsigned int Capacity>
template <unsigned int Capacity2>
StaticArray<T, Capacity>::StaticArray(const StaticArray<T, Capacity2> &other)
{
	// Self-assignment check is not needed as the other array is surely different
	const unsigned int newSize = (other.size() < Capacity) ? other.size() : Capacity;

	size_ = newSize;
	copyConstructArray(array_, other.data(), newSize);
}

/*! \note Copy could be truncated if the other array is bigger than its capacity. */
template <class T, unsigned int Capacity>
template <unsigned int Capacity2>
StaticArray<T, Capacity> &StaticArray<T, Capacity>::operator=(const StaticArray<T, Capacity2> &other)
{
	// Self-assignment check is not needed as the other array is surely different
	const unsigned int newSize = (other.size() < Capacity) ? other.size() : Capacity;

	if (newSize >= size_)
	{
		copyAssignArray(array_, other.data(), size_);
		copyConstructArray(array_ + size_, other.data() + size_, newSize - size_);
	}
	else
	{
		copyAssignArray(array_, other.data(), newSize);
		destructArray(array_ + newSize, size_ - newSize);
	}

	size_ = newSize;
	return *this;
}

template <class T, unsigned int Capacity>
void StaticArray<T, Capacity>::setSize(unsigned int newSize)
{
	const int newElements = newSize - size_;

	if (newSize > Capacity)
	{
		LOGW_X("Trying to extend the size of a static array beyond its cpacity, from from %u to %u", Capacity, newSize);
		return;
	}

	if (newElements > 0)
		constructArray(array_ + size_, newElements);
	else if (newElements < 0)
		destructArray(array_ + size_ + newElements, -newElements);
	size_ += newElements;
}

/*! Size will be set to zero but capacity remains unmodified. */
template <class T, unsigned int Capacity>
void StaticArray<T, Capacity>::clear()
{
	destructArray(array_, size_);
	size_ = 0;
}

template <class T, unsigned int Capacity>
const T &StaticArray<T, Capacity>::front() const
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot retrieve an element from an empty array");
	return array_[0];
}

template <class T, unsigned int Capacity>
T &StaticArray<T, Capacity>::front()
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot retrieve an element from an empty array");
	return array_[0];
}

template <class T, unsigned int Capacity>
const T &StaticArray<T, Capacity>::back() const
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot retrieve an element from an empty array");
	return array_[size_ - 1];
}

template <class T, unsigned int Capacity>
T &StaticArray<T, Capacity>::back()
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot retrieve an element from an empty array");
	return array_[size_ - 1];
}

template <class T, unsigned int Capacity>
template <typename... Args>
void StaticArray<T, Capacity>::emplaceBack(Args &&... args)
{
	new (extendOne()) T(nctl::forward<Args>(args)...);
}

template <class T, unsigned int Capacity>
void StaticArray<T, Capacity>::popBack()
{
	FATAL_ASSERT_MSG(size_ > 0, "Cannot pop an element from an empty array");
	destructObject(array_ + size_ - 1);
	size_--;
}

template <class T, unsigned int Capacity>
T *StaticArray<T, Capacity>::insertRange(unsigned int index, const T *firstPtr, const T *lastPtr)
{
	// Cannot insert at more than one position after the last element
	FATAL_ASSERT_MSG_X(index <= size_, "Index %u is out of bounds (size: %u)", index, size_);
	FATAL_ASSERT_MSG_X(firstPtr <= lastPtr, "First pointer %p should precede or be equal to the last one %p", firstPtr, lastPtr);

	const unsigned int numElements = static_cast<unsigned int>(lastPtr - firstPtr);
	if (numElements == 0)
		return (array_ + index);
	FATAL_ASSERT_MSG_X(size_ + numElements <= Capacity, "Can't add element beyond capacity (%d)", Capacity);

	// Backwards loop to account for overlapping areas
	for (unsigned int i = size_ - index; i > 0; i--)
	{
		T *src = &array_[index + i - 1];
		T *dst = &array_[index + numElements + i - 1];

		moveConstructObject(dst, src);
		destructObject(src);
	}
	copyConstructArray(array_ + index, firstPtr, numElements);
	size_ += numElements;

	return (array_ + index + numElements);
}

template <class T, unsigned int Capacity>
T *StaticArray<T, Capacity>::insertRange(unsigned int index, std::initializer_list<T> initList)
{
	typename std::initializer_list<T>::const_iterator end = initList.end();
	const unsigned int MaxInsertions = Capacity - size_;
	if (end - initList.begin() > MaxInsertions)
		end = initList.begin() + MaxInsertions;

	return insertRange(index, initList.begin(), end);
}

template <class T, unsigned int Capacity>
T *StaticArray<T, Capacity>::insertAt(unsigned int index, const T &element)
{
	// Cannot insert at more than one position after the last element
	FATAL_ASSERT_MSG_X(index <= size_, "Index %u is out of bounds (size: %u)", index, size_);
	FATAL_ASSERT_MSG_X(size_ + 1 <= Capacity, "Can't add element beyond capacity (%d)", Capacity);

	if (index < size_)
	{
		// Backwards loop to move-construct into the next slot
		for (unsigned int i = size_; i > index; i--)
		{
			T *src = &array_[i - 1];
			T *dst = &array_[i];

			moveConstructObject(dst, src);
			destructObject(src);
		}
	}
	copyConstructObject(array_ + index, &element);
	size_++;

	return (array_ + index + 1);
}

template <class T, unsigned int Capacity>
T *StaticArray<T, Capacity>::insertAt(unsigned int index, T &&element)
{
	// Cannot insert at more than one position after the last element
	FATAL_ASSERT_MSG_X(index <= size_, "Index %u is out of bounds (size: %u)", index, size_);
	FATAL_ASSERT_MSG_X(size_ + 1 <= Capacity, "Can't add element beyond capacity (%d)", Capacity);

	if (index < size_)
	{
		for (unsigned int i = size_; i > index; i--)
		{
			T *src = &array_[i - 1];
			T *dst = &array_[i];

			moveConstructObject(dst, src);
			destructObject(src);
		}
	}
	moveConstructObject(array_ + index, &element);
	size_++;

	return (array_ + index + 1);
}

template <class T, unsigned int Capacity>
template <typename... Args>
T *StaticArray<T, Capacity>::emplaceAt(unsigned int index, Args &&... args)
{
	// Cannot emplace at more than one position after the last element
	FATAL_ASSERT_MSG_X(index <= size_, "Index %u is out of bounds (size: %u)", index, size_);
	FATAL_ASSERT_MSG_X(size_ + 1 <= Capacity, "Can't add element beyond capacity (%d)", Capacity);

	if (index < size_)
	{
		for (unsigned int i = size_; i > index; i--)
		{
			T *src = &array_[i - 1];
			T *dst = &array_[i];

			moveConstructObject(dst, src);
			destructObject(src);
		}
	}
	new (array_ + index) T(nctl::forward<Args>(args)...);
	size_++;

	return (array_ + index + 1);
}

template <class T, unsigned int Capacity>
typename StaticArray<T, Capacity>::Iterator StaticArray<T, Capacity>::insert(Iterator position, const T &value)
{
	const unsigned int index = &(*position) - array_;
	T *nextElement = insertAt(index, value);

	return Iterator(nextElement);
}

template <class T, unsigned int Capacity>
typename StaticArray<T, Capacity>::Iterator StaticArray<T, Capacity>::insert(Iterator position, T &&value)
{
	const unsigned int index = &(*position) - array_;
	T *nextElement = insertAt(index, nctl::move(value));

	return Iterator(nextElement);
}

template <class T, unsigned int Capacity>
typename StaticArray<T, Capacity>::Iterator StaticArray<T, Capacity>::insert(Iterator position, Iterator first, Iterator last)
{
	const unsigned int index = static_cast<unsigned int>(&(*position) - array_);
	const T *firstPtr = &(*first);
	const T *lastPtr = &(*last);
	T *nextElement = insertRange(index, firstPtr, lastPtr);

	return Iterator(nextElement);
}

template <class T, unsigned int Capacity>
typename StaticArray<T, Capacity>::Iterator StaticArray<T, Capacity>::insert(Iterator position, std::initializer_list<T> initList)
{
	const unsigned int index = static_cast<unsigned int>(&(*position) - array_);
	T *nextElement = insertRange(index, initList);

	return Iterator(nextElement);
}

template <class T, unsigned int Capacity>
template <typename... Args>
typename StaticArray<T, Capacity>::Iterator StaticArray<T, Capacity>::emplace(Iterator position, Args &&... args)
{
	const unsigned int index = &(*position) - array_;
	T *nextElement = emplaceAt(index, nctl::forward<Args>(args)...);

	return Iterator(nextElement);
}

template <class T, unsigned int Capacity>
T *StaticArray<T, Capacity>::removeRange(unsigned int firstIndex, unsigned int lastIndex)
{
	// Cannot remove past the last element
	FATAL_ASSERT_MSG_X(firstIndex < size_, "First index %u out of size range", firstIndex);
	FATAL_ASSERT_MSG_X(lastIndex <= size_, "Last index %u out of size range", lastIndex);
	FATAL_ASSERT_MSG_X(firstIndex <= lastIndex, "First index %u should precede or be equal to the last one %u", firstIndex, lastIndex);

	const unsigned int numElements = lastIndex - firstIndex;
	moveAssignArray(array_ + firstIndex, array_ + lastIndex, size_ - lastIndex);
	destructArray(array_ + size_ - numElements, numElements);
	size_ -= numElements;

	return (array_ + firstIndex);
}

template <class T, unsigned int Capacity>
typename StaticArray<T, Capacity>::Iterator StaticArray<T, Capacity>::erase(Iterator position)
{
	const unsigned int index = static_cast<unsigned int>(&(*position) - array_);
	return removeAt(index);
}

template <class T, unsigned int Capacity>
typename StaticArray<T, Capacity>::Iterator StaticArray<T, Capacity>::erase(Iterator first, Iterator last)
{
	const unsigned int firstIndex = static_cast<unsigned int>(&(*first) - array_);
	const unsigned int lastIndex = static_cast<unsigned int>(&(*last) - array_);
	T *nextElement = removeRange(firstIndex, lastIndex);

	return Iterator(nextElement);
}

/*! \note This method is faster than `removeRange()` but it will not preserve the array order */
template <class T, unsigned int Capacity>
T *StaticArray<T, Capacity>::unorderedRemoveRange(unsigned int firstIndex, unsigned int lastIndex)
{
	// Cannot remove past the last element
	FATAL_ASSERT_MSG_X(firstIndex < size_, "First index %u out of size range", firstIndex);
	FATAL_ASSERT_MSG_X(lastIndex <= size_, "Last index %u out of size range", lastIndex);
	FATAL_ASSERT_MSG_X(firstIndex <= lastIndex, "First index %u should precede or be equal to the last one %u", firstIndex, lastIndex);

	const unsigned int numElements = lastIndex - firstIndex;
	for (unsigned int i = 0; i < numElements; i++)
		array_[firstIndex + i] = nctl::move(array_[size_ - i - 1]);
	destructArray(array_ + size_ - numElements, numElements);
	size_ -= numElements;

	return (array_ + firstIndex + 1);
}

/*! \note This method is faster than `erase()` but it will not preserve the array order */
template <class T, unsigned int Capacity>
typename StaticArray<T, Capacity>::Iterator StaticArray<T, Capacity>::unorderedErase(Iterator position)
{
	const unsigned int index = static_cast<unsigned int>(&(*position) - array_);
	return unorderedRemoveAt(index);
}

/*! \note This method is faster than `erase()` but it will not preserve the array order */
template <class T, unsigned int Capacity>
typename StaticArray<T, Capacity>::Iterator StaticArray<T, Capacity>::unorderedErase(Iterator first, Iterator last)
{
	const unsigned int firstIndex = static_cast<unsigned int>(&(*first) - array_);
	const unsigned int lastIndex = static_cast<unsigned int>(&(*last) - array_);
	T *nextElement = unorderedRemoveRange(firstIndex, lastIndex);

	return Iterator(nextElement);
}

template <class T, unsigned int Capacity>
const T &StaticArray<T, Capacity>::at(unsigned int index) const
{
	FATAL_ASSERT_MSG_X(index < size_, "Index %u is out of bounds (size: %u)", index, size_);
	return operator[](index);
}

template <class T, unsigned int Capacity>
T &StaticArray<T, Capacity>::at(unsigned int index)
{
	// Avoid creating "holes" into the array
	FATAL_ASSERT_MSG_X(index <= size_, "Index %u is out of bounds (size: %u)", index, size_);
	return operator[](index);
}

template <class T, unsigned int Capacity>
const T &StaticArray<T, Capacity>::operator[](unsigned int index) const
{
	ASSERT_MSG_X(index < size_, "Index %u is out of bounds (size: %u)", index, size_);
	return array_[index];
}

template <class T, unsigned int Capacity>
T &StaticArray<T, Capacity>::operator[](unsigned int index)
{
	ASSERT_MSG_X(index < size_, "Index %u is out of bounds (size: %u)", index, size_);
	return array_[index];
}

template <class T, unsigned int Capacity>
T *StaticArray<T, Capacity>::extendOne()
{
	FATAL_ASSERT_MSG_X(size_ < Capacity, "Cannot extend static array size beyond capacity (%u elements)", Capacity);
	size_++;
	return array_ + size_ - 1;
}

}

#endif
